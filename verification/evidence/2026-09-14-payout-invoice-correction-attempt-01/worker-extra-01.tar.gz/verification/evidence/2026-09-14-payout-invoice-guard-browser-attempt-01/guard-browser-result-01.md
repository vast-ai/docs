# Offline payout source-disclosure check — guard browser 01

Result: PASS for `MCL-3afd93ae0b6cf8a4` in the current local `verification/host-docs-review.html`.

The collapsed disclosure is labeled **Published guidance checked**. Native browser activation expands it and exposes two distinct **Open exact bound source excerpt** controls:

- Basis 0 opens **Published Host Payouts guidance — payment-timeline**.
- Basis 1 opens **Hosting Agreement — USE OF HARDWARE**.

Both opened the **Exact bound source excerpt** dialog, retained the claim’s PASS-within-scope boundary, and showed their separately bounded source text. Screenshots: `guard-browser-04-basis-0.png` and `guard-browser-05-basis-1.png`.

The agent-browser selector click did not toggle the summary while it was off-screen, and its scroll command did not bring the summary into the visual viewport. Native browser activation in that same isolated session did toggle `details.open`, and both buttons then worked. Treat the selector behavior as an automation viewport limitation, not a disclosure-control defect.

Scope limit: local offline presentation only; no remote navigation, account action, publication check, invoice generation, payment processing, or payout outcome was tested.
