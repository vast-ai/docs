# Correction disposition — offline payout source-disclosure check

This record corrects the conclusion in `guard-browser-result-01.md` without overwriting it.

## Target identity

The browser opened only the worker file:

`file:///Users/hanneszietsman/VastAi/CON-1584/docs-pr153-host-cli-api-sdk/.orchestra/payout-invoice/worker/verification/host-docs-review.html`

At the later identity check its SHA-256 was `35d00ba04bbcbce88101690b0e2f61ec9704604d37a8cf9ff552cc8d5724f298`.

The repository-root counterpart was **not** opened or inspected in this browser attempt:

`/Users/hanneszietsman/VastAi/CON-1584/docs-pr153-host-cli-api-sdk/verification/host-docs-review.html`

Its SHA-256 at the identity check was `c4e12d6fefe6e24e0e0655b6dd993478b53d063823630a27ac1e47ddb56dbd7e`.

## Exact browser actions and observations

The session used these classes of commands against the worker file:

1. `agent-browser --session payout-invoice-guard open file:///…/worker/verification/host-docs-review.html`
2. `agent-browser --session payout-invoice-guard snapshot -i -c`
3. `agent-browser --session payout-invoice-guard select @e24 "Host Payouts"` and `select @e25 "PASS"`
4. DOM inspection with `agent-browser … eval` confirmed that `MCL-3afd93ae0b6cf8a4` contained a closed `details.callout.partial`, summary text `Published guidance checked`, and two `button[data-basis]` controls (basis 0 and 1).
5. `agent-browser … click "#claim-MCL-3afd93ae0b6cf8a4 details.callout.partial > summary"` was attempted twice. On each post-click DOM inspection, `details.open` remained `false`; it is therefore not positive activation evidence.
6. `agent-browser … click "#claim-MCL-3afd93ae0b6cf8a4 details.callout.partial button[data-basis='0']"` was attempted. The dialog remained closed; it is therefore not positive activation evidence.
7. The later successful expansion and source-dialog displays used `agent-browser … eval` with `summary.click()` and `button.click()`. Those are **programmatic DOM activations**, not trusted human/native-input clicks. The basis-0 and basis-1 screenshots prove the controls and handlers exist in the worker DOM, but do not prove a human can activate them.

No trusted physical/native browser click, keyboard activation, or accessibility-tree ref activation of the target disclosure/button was captured successfully. Do not infer a human-facing PASS, defect, or automation-viewport cause from this attempt.

## Disposition

The worker DOM statically contains the expected disclosure and two separately mapped controls. Human-facing activation is **INCONCLUSIVE** in this evidence attempt. Root HTML is a different byte identity and is outside the attempted browser target; main's independent root-visible-control inspection is required for that conclusion.

Scope remains local presentation only: no remote navigation, account action, publication check, invoice generation, payment processing, or payout outcome was exercised.
